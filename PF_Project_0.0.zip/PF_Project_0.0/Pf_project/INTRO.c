#include<stdio.h>
#include<string.h>
#include<windows.h>
#include<conio.h>
#include<math.h>
#include"./headers/PATH_1_Old_Men_and_child.h"
#include"./headers/Path2_header.h"
#include"./headers/Global_variable.h"


char user_file[100];
// ANSI color codes for text color
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_RESET   "\x1b[0m"

//int mWatch_present=0;
void path_select();
int PageOne();
int Starting_manu();
void monologue1();
void newGame();
void displayColored();


int main()
{
	int i;
    i = PageOne();
    if (i==1)
    {
    	return 0;
	}
	else
	{
		Starting_manu();
	}
    
    
}

//Function Definition

void path_select() {
char path[100];
    int condition_path = 0;

    while (condition_path == 0)
     {
        printf("\t\t\t\t--->");
        scanf("%s", path); 
   
        char answer1 = 'a', answer2 = 'b';
    if(strlen(path)==1)
    {
        path[0]=tol(path[0]);
        if (path[0] == answer1) 
        {
                condition_path = 1;
                PATH_1_Old_Men_and_child();
            // Path a function
        } 
        else if (path[0] == answer2) 
        {
            path2_start();
            // Path b function
        } 
        else 
        {
            printf("\n\t\t\t\tWrong input, try again\n");
            Sleep(1500);  
        }
    }
    else
    {
        printf("\n\t\t\t ??????WRONG INPUT ??????");
        Sleep(1500);

    }
  }
    
}



int PageOne()
{
    //intro for the game first page 
	
    system("cls");
    Sleep(50);
    printf("\n\t                                                                       *");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       **");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ***");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****");
    Sleep(50);
    system("cls"); 
    printf("\n\t                                                                       *****");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ******");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *******");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *********");
    Sleep(50);
    system("cls");  
    printf("\n\t                                                                       **********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ***********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ************");
    Sleep(50);
    system("cls");  
    printf("\n\t                                                                       *************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       **************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ***************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *****************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ******************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *******************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       **********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ***********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       *************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       **************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ***************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************");
    Sleep(50);
     
    printf("\n\t\t                                     \t\t                W");
    Sleep(150);
    printf("\b E");
    Sleep(150);
    printf("\b L");
    Sleep(150);
    printf("\b C");
    Sleep(150);
    printf("\b O");
    Sleep(150);
    printf("\b M");
    Sleep(150);
    printf("\b E");
    Sleep(150);
    printf("\bWELCOME ");
    Sleep(150);
    printf("\b T");
    Sleep(150);
    printf("\b O");
    Sleep(150);
    printf("\b\bTO ");
    Sleep(150);
    printf("\b A");
    Sleep(150);
    printf("\b D");
    Sleep(150);
    printf("\b V");
    Sleep(150);
    printf("\b E");
    Sleep(150);
    printf("\b N");
    Sleep(150);
    printf("\b T");
    Sleep(150);
    printf("\b U");
    Sleep(150);
    printf("\b R");
    Sleep(150);
    printf("\b E");
    Sleep(150);
    printf("\b ADVENTURE");
    Sleep(150);
    printf("\b Q");
    Sleep(150);
    printf("\b U");
    Sleep(150);
    printf("\b E");
    Sleep(150);
    printf("\b S");
    Sleep(150);
    printf("\b T");
    Sleep(150);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       **");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ***");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ****");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *****");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ******");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *******");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       **********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ***********");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       **************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ***************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ****************"); 
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *****************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ******************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *******************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       **********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ***********************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       *************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ***************************");
    Sleep(50);
    system("cls");
    printf("\n\t                                                                       ****************************\n\t\t\t\t\t\t\t\t\t        WELCOME TO ADVENTURE QUEST");
    printf("\n\t                                                                       ****************************");
    Sleep(50);
    printf("\n\n\t                                                                            ADVENTURE");
    Sleep(400);
    printf("  AWAITS!!");
    //Sleep(400);
    //system("cls");
    printf("\n\n\t                                                                     Press Enter to play or Esc to exit.\n");

		char key;
        key = getch(); // to take input wether to continue or exit
        
        if (key == 13) { // ASCII code for Enter key
            
            printf("\t                                                                l");
            Sleep(50);
            system("cls");
            printf("\t                                                                lo");
            Sleep(50);
            system("cls");
            printf("\t                                                                loa");
            Sleep(50);
            system("cls");
            printf("\t                                                                load");
            Sleep(50);
            system("cls");
            printf("\t                                                                loadi");
            Sleep(50);
            system("cls");
            printf("\t                                                                loadin");
            Sleep(50);
            system("cls");
            printf("\t                                                                loading");
            Sleep(50);
            system("cls");
            printf("\t                                                                loading.");
            Sleep(50);
            system("cls");
			printf("\t                                                                loading..");
            Sleep(50);
            system("cls");
            printf("\t                                                                loaing...");
            Sleep(50);
        } 
		else if (key == 27) { // ASCII code for Esc key
            printf("Exiting...\n");
            return 1;
            
    }
}
void monologue1()
{    
    
	system("cls");
	printf("\n\n\n\n\n");
	//display first story 
	printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  One day cleaning out your grand father's room after his tragic death you stumble    |)\n");
    printf("\t\t\t     (|  upon an old cryptic map that hints at the location of a legendary, long lost        |)\n");
    printf("\t\t\t     (|  treasure deep within a dense jungle. Just like a curious archeologist you are, you  |)\n");
    printf("\t\t\t     (|  decide to to follow it and find the treasure despite not knowing where it will lead |)\n");
    printf("\t\t\t     (|  to. This marks the beginning of your adventure.                                     |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                   !!!!GOOD LUCK!!!!                                  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(20000);
    system("cls");
    
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (| Your first location is a jungle, a dense green forest with predetory animals. Where  |)\n");
    printf("\t\t\t     (| if you ever lose your track you are never to be found again. Be careful on the way,  |)\n");
    printf("\t\t\t     (| you may encounter animals humans orrrr two paths oh what a coincidence you have two  |)\n");
    printf("\t\t\t     (| paths to choose from which one do u choose path \"A\" hmmm it looks like noone uses    |)\n");
    printf("\t\t\t     (| this path there are all these shrubs and plants growing on it and the other path \"B\" |)\n");
    printf("\t\t\t     (| looks like it has seen quite the amount of people its clear and looks kinda safe.    |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                 CHOOSE: PATH A OR PATH B                             |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(20000);
    path_select();
}


int Starting_manu()
{
    char choice[50];
     while(1) 
     {
        system("cls"); 

        displayColored("\t\t\t\t(|============================================|)", ANSI_COLOR_YELLOW);
        printf("\t\t\t\t(|Menu:\n");
        displayColored("\t\t\t\t1. New Game                                   |)", ANSI_COLOR_GREEN);
        displayColored("\t\t\t\t2. Exit", ANSI_COLOR_RED);
        displayColored("\t\t\t\t(|============================================|)", ANSI_COLOR_YELLOW);


        printf("\t\t\t\tEnter your choice: ");
        scanf("%s", choice);
        if(strlen(choice)==1)
        {
            if(choice[0]=='1')
            {
             monologue1(); 
            }
            else if(choice[0]=='2')
            {
            
                printf("Exiting the program. Goodbye!\n");
                break;
            }
        else
        {
            printf("\n!!!!! Invalid Input !!!!!");
        }
        }
        else
        {
            printf("\n!!!!!!Invalid Input !!!!!");
        }
        Sleep(3000);
        getchar();

        }
          // Wait for the user to press Enter before displaying the menu again
        Sleep(1000);

    } 





void displayColored(char *text, char *color)
 {
    printf("%s%s%s\n", color, text, ANSI_COLOR_RESET);
}