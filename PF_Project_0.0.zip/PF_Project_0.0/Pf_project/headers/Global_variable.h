#ifndef GLOBAL_VARIABLE_H 
#define GLOBAL_VARIABLE_H

extern char user_file[100];  
extern int visited_east;
extern int visited_west;
extern int monkey_presence;
extern int presence_of_old_man;
extern int watch_present_lost;
extern int weapon_presence;
#endif
