#ifndef PATH1_RABBIT_HEADER_H
#define PATH1_RABBIT_HEADER_H

int Rabbit();
void R_Story_line_path2_Rabbit();
int R_Rabbit_path_directions();
char R_mchoice_y_n();
void R_Directional_moves();
int R_Bar_story();
char R_choice_y_n();
int Watch_presence();
#endif