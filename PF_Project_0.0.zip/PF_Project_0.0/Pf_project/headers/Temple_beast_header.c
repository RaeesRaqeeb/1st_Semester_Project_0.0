#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<time.h>
#include"Temple_beast_header.h"
#include"Path1_Rabbit_header.h"
#include"Global_variable.h"
#include"windows.h"
#include"Ending_Script_without_oldman.h"
#include"End_script_with_oldman.h"


int presence_of_old_man=0;

void Entering_temple()
{	printf("\n\t\t\t ********** ADDING CHECKPOINT **********\n");
	Sleep(1000);
	printf("\n\t\t\t(|As you enter the temple you saw a Beast. Half Human )|");
	printf("\n\t\t\t(|Half Ware-Wolve. You want to talk or Fight          )|");
	printf("\n\t\t\t(|            Fight or Talk                           )|");
	char Temple_decision1[20];
	int condition=0;
	while(condition==0)
	{
	printf("\n\t\t\t~>");
	scanf(" %s", Temple_decision1);
	 for (int i = 0; i < strlen(Temple_decision1); i++) 
	 {
        	Temple_decision1[i] = tolower(Temple_decision1[i]);
         }

    	char answer1[] = {"fight"}, answer2[] = {"talk"};
    	if((strcmp(Temple_decision1,answer1)==0) || (strcmp(Temple_decision1,answer2)==0))
    	{
    	++condition;
	if(strcmp(Temple_decision1,answer1)==0)
	{
		fighting_beast();
		condition=1;
		//call the funciton header file using file handling check that player has weapon or not
	}
	else if(strcmp(Temple_decision1,answer2)==0)
	{
		
		printf("\n\t\t\t(|Temple_Beast: Traveler! If you give me correct answers of these three questions|)");
		printf("\n\t\t\t(|and gave me what I will ask you to give them you can have the treasure         |)");
		//(5000);
		printf("\n\t\t\t(|Your first question is                                                         |)");
		
		printf("\n\n\t\t\t(|Q:The person who makes it, sells it. The person who buys it never uses it. The |)");
		printf("\n\t\t\t(|person who uses it never knows they're using it. What is it?                   |)");
		
		char User_answer[20];
		printf("\n\t\t\t~>");
		scanf("%s", User_answer);
		 for (int i = 0; i < strlen(User_answer); i++) 
	 		{
        			User_answer[i] = tolower(User_answer[i]);
         	}
			
		if(strcmp(User_answer,"coffin")==0)
		{
			
			
			printf("\n\t\t\t(|Good! Second Question                             |)");
			printf("\n\n\t\t\t(|Q: I am taken from a mine and am very, very dirty.|)");
			printf("\n\t\t\t(|I'm not made of metal, but I'm worth a lot of     |)");
			printf("\n\t\t\t(|money. What am I?                                 |)");
			char User_answer2[20];
			printf("\n\t\t\t~>");
			scanf("%s", User_answer2);
			 for (int i = 0; i < strlen(User_answer2); i++) 
	 			{
        				User_answer2[i] = tolower(User_answer2[i]);
         			}
			
			if(strcmp(User_answer2,"diamond")==0)
			{
				int checker=0;
				printf("\n\t\t\t(|Good! Third Question                             |)");
				printf("\n\t\t\t(|Q:I'm not alive, but I can grow; I don't have    |)");
				printf("\n\t\t\t(|lungs, but I need air; I don't have a mouth, but |)");
				printf("\n\t\t\t(|water kills me. What am I?                       |)");
				char User_answer3[20];
				printf("\n\t\t\t~>");
				scanf("%s", User_answer3);
				 for (int i = 0; i < strlen(User_answer3); i++) 
	 				{
        					User_answer3[i] = tolower(User_answer3[i]);
         				}
         				if(strcmp(User_answer3,"fire")==0)
         				{
         					printf("\n\t\t\t(|Temple_Beast: Brillent! One last thing Give me the....|)");
         					printf("\n\t\t\t(|Watch..................                               |)");
         					   Back_form_rabbit();
         				}
						else
						{
							printf("\n\t\t\t (|Temple Beast: You are gone die |)");
							fighting_beast();
						}
				
			}
			else
			{
				printf("\n\t\t\t(|WRONG ANSWER! You are gone die");
				Sleep(2000);
				fighting_beast();
			//Call the child function if you have the sword you will win the fight other wise die
			}
				
		}
		else
		{
			printf("\n\t\t\t(|WRONG ANSWER! You are gone die");
			fighting_beast();
			//Call the child function if you have the sword you will win the fight other wise die
		}
	}
    }
    else
    {
    	printf("\n\t\t\tInvalid input");
    }
    
 }
 
 }
	


void Back_form_rabbit()
{	
         		char User_input1[100];
         		if(visited_east==0)
					{  
							 int return_condition=0; 
						while(return_condition==0)
						{
							printf("\n\t\t\t Hint: *****You should Follow the rabbit****\n");
         					printf("\n\t\t\t(|Press R/r to return to the jungle|)");
         					printf("\n\t\t\t~>");
         					scanf(" %s", User_input1);
							if(strlen(User_input1)==1)
							{
         						if(User_input1[0]=='R' || User_input1[0]=='r')
         						{
									//call the function of rabbit program
									return_condition=1;
									R_Rabbit_path_directions();
									Back_form_rabbit();
									
								}
									else
									{
										printf("\n\t\t\t?????? INVALID INPUT ????????");
									}
							}
						}
					}
							else if(visited_east==1 && visited_west==0)
							{
								printf("\n\t\t\t You come back to the temple with watch\n");
								printf("\n\t\t\t(|!!!!!!!!!!(Player:Here is your watch )!!!!!!!!!!|)");
										if(presence_of_old_man==1)
										{
											old_man();
										}
										else if(presence_of_old_man==0)
										{
											with_out_old_man();
										}
								Sleep(5000);
							}
							else if(visited_east==1 && watch_present_lost==0)
							{
								printf("\n\t\t\t YOU HAVE LOST THE WATCH IN BAR\n");
								fighting_beast();
								
								Sleep(5000);
							}
							else if((visited_east==1 && watch_present_lost==1 && visited_west==1))
							{
								printf("\n\t\t\t You come back to the temple with watch\n");
								printf("\n\t\t\t(|!!!!!!!!!!(Player:Here is your watch )!!!!!!!!!!|)");
										if(presence_of_old_man==1)
										{
											old_man();
										}
										else if(presence_of_old_man==0)
										{
											with_out_old_man();
										}
								Sleep(5000);
							}
         					
}



int fighting_beast()
{
   

        if (weapon_presence == 1)
        {
            printf("\n\t\t\t( !!!!!!!! FIGHT START !!!!!!!!)\n");
            Sleep(3000);
            printf("\n\t\t\t(!!!YOU WIN THE FIGHT BECAUSE YOU WERE LUCKY YOU HAD THE WEAPON TO DEFEAT THE BEAST)");
            if (presence_of_old_man == 1)
            {
                old_man();
            }
            else if (presence_of_old_man == 0)
            {
                with_out_old_man();
            }
            
            return 0;
        }
        else if(weapon_presence==0)
        {
            Sleep(3000);
            printf("\n\t\t\t BEAST IS ANGRY!\n\t\t\tBEAST: YOU ARE GONNA DIE!\n");

            Sleep(5000);
            if ((visited_east == 1 && watch_present_lost == 1) || visited_east == 0)
            {
                printf("\n\t\t\t(| YOU DIED BECAUSE YOU didn't have anything to defend |)\n");
                printf("\n\t\t\t *********Returning to checkpoint******");
                Sleep(2000);

                system("cls");
                Entering_temple();
            }
        }
		 printf("\n\t\t\t (!!!!! YOU HAVE BEEN KILLED BY THE BEAST !!!!!!!)\n\t\t\t !!!!!!!GAME OVER !!!!!!!");
    Sleep(5000);
    return 0;
    }

  
   

