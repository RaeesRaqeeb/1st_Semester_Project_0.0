#include "Global_variable.h"

  
int visited_east=0;
int visited_west=0;
int monkey_presence=0;
int watch_present_lost=0;
int weapon_presence=0;

