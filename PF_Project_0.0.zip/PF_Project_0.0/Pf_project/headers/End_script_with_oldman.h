#ifndef END_SCRIPT_WITH_OLDMAN_H
#define END_SCRIPT_WITH_OLDMAN_H

int with_old_man(char* text);
int old_man();



#endif