#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<windows.h>
#include<time.h>
#include"Temple_beast_header.h"
#include"Path1_Rabbit_header.h"
#include"Temple_gate_header.h"
#include"PATH_1_Old_Men_and_child.h"
#include"Global_variable.h"


//Main function of this File
int Rabbit()
{ 

	int temple_condition=0;
	temple_condition=R_Rabbit_path_directions(); 
	//If else is used to insure the proper flow when user return from the inside of temple for watch then he don't have to play the entering temple game.
	if(temple_condition==1){
		Entering_temple();
	}
	else{
	Temple_gate();
	Entering_temple();
	}
	
    
    return 0;

}

// FUNCTIONS DEFINITIONS

int R_Rabbit_path_directions()
{
	printf("\n\t\t\t ************ADDING CHECKPOINT********");  // If player died or lose game before the next checkpoint the game will continue from here.

	 if(R_choice_y_n()=='y')
     {
	 char Direction[100];
	printf("\t\t\t     (|======================================================================================|)\n"); 
	printf("\t\t\t     (|                           SO YOU DECIDE TO FOLLOW THE RABBIT                         |)\n");
	printf("\t\t\t     (|                                THEN YOU MUST FIND IT!!!                              |)\n");
	printf("\t\t\t     (|======================================================================================|)\n");

	int condition=0, Rabit_found=0;

//if the user input wrong value then program will not end there.
	while(condition==0)
	{
		printf("\n\t\t\tWrite you turn North, south, east, or west.");
		printf("\n\t\t\t~>");
		scanf(" %s", Direction);
		for(int i=0;i<=strlen(Direction);++i)
		{
			Direction[i]=tol(Direction[i]);
		}
	if(strcmp(Direction,"north")==0)
	{
		system("cls");
    printf("\t\t\t*****************************There you saw a beautiful mountains and Amazing waterfall********************************\n");
    printf("\t\t\t\t\t\t        /\\          \n");
    Sleep(500);  // Sleep for 0.5 seconds
    printf("\t\t\t\t\t\t       /  \\         \n");
    Sleep(500);
    printf("\t\t\t\t\t\t      /    \\        \n");
    Sleep(500);
    printf("\t\t\t\t\t\t     /      \\       \n");
    Sleep(500);
    printf("\t\t\t\t\t\t    /        \\      \n");
    Sleep(500);
    printf("\t\t\t\t\t\t   /   /\\     \\     \n");
    Sleep(500);
    printf("\t\t\t\t\t\t  /   /  \\     \\    \n");
    Sleep(500);
    printf("\t\t\t\t\t\t /   /    \\     \\   \n");
    Sleep(500);
    printf("\t\t\t\t\t\t/___/______\\_____\\  \n");
    Sleep(500);
    printf("\t\t\t\t\t\t     Mountains     \n");
	
	printf("\n\t\t\t*****************************But there was no rabbit*****************************");
	printf("\n\t\t\t     (|    Press 'n' if you want to discover more. Otherwise 'y' to continue your journey. |) \n");
		char Journey_con[100];
		int North_condition=0;
		while(North_condition==0)
		{
		printf("\n\t\t\t~>");
		scanf(" %s", Journey_con);
		
					if(strlen(Journey_con)==1)
					{
		     			if((Journey_con[0]=='y') || (Journey_con[0]=='y'))
    				{
    					condition=1;
						North_condition=1;
    				}
					else if((Journey_con[0]=='n') || (Journey_con[0]=='N'))
					{
						North_condition=1;
						condition=0;
					}

				}
					else
					{
						printf("\n\t\t\t ?????? INVALID INPUT ???????");
					}
		}
	}
	else if(strcmp(Direction,"south")==0)
	{
		printf("\n\t\t\tYou come back to the village. People are so busy as usual.");
		printf("\n\t\t\t     (|    Press 'n' if you want to discover more. Otherwise 'y' to continue your journey.                                             |) \n");
		char Journey_con[100];
		int south_condition=0;
		while(south_condition==0)
		{
		printf("\n\t\t\t~>");
		scanf("%s", Journey_con);
		system("cls");
					if(strlen(Journey_con)==1)
					{
		     			if( (Journey_con[0]=='Y') || (Journey_con[0]=='y'))
    				{
    					condition=1;
    				}
					else if( (Journey_con[0]=='N') || (Journey_con[0]=='n'))
						{
							south_condition=1;

						}
						
					}
					else
					{
						printf("\n\t\t\t ??????? INVALID INPUT ???????");
					}
		}
	}
	else if(strcmp(Direction,"west")==0 )
	    {
			if(visited_west==0)
			{
			visited_west=1;
		char decision_bar[100];
	printf("\n\t\t\tWhen you move through the bushes you saw a Bar house little far. You are little thirty. would you like to go there?(y/n)");
	
		int bar_condition=0;
		while(bar_condition==0)
		{
		printf("\n\t\t\t~>");
		scanf(" %s", decision_bar);
		system("cls");
					if(strlen(decision_bar)==1)
					{
		     			if((strcmp(decision_bar,"y")==0) ||(strcmp(decision_bar,"Y")==0))
    					{
		    				 bar_condition=R_Bar_story();
						}
					else if((strcmp(decision_bar,"n")==0) ||(strcmp(decision_bar,"N")==0))
						{
							printf("\n\t\t\t     (|    Press 'n' if you want to discover more. Otherwise 'y' to continue your journey.                                             |) \n");
							char Journey_con;
							printf("\n\t\t\t     ~>");
							scanf(" %c",&Journey_con);
							
							system("cls");
									if(Journey_con=='y' || Journey_con=='Y')
											{
												condition=1;
												bar_condition=1;
										}
										else if((Journey_con=='n' || Journey_con=='N'))
										{
											bar_condition=1;
										}
    					}
						else
						{
							printf("\n\t\t\t ??????????? INVALID INPUT ????????");
						}
		
	    			}
					else
					{
						printf("\n\t\t\t ???????? INVALID INPUT ?????????");
					}
					Sleep(2000);
					system("cls");
		}
			}
			else if(visited_west==1)
			{
				printf("\n\t\t\t(| You already been here. THere is nothing new.)");
				Sleep(1000);
			}
	}
	else if((strcmp(Direction,"east")==0) )
	 {
	 char Journey_con;
	 	if(visited_east==0)
	 	{
		visited_east=1;
	
		 // this shows that player first move to east and then he went to the bar house it will change story little bit 
		watch_present_lost=1;
		system("cls");
	printf("\t\t\t     (|=======================================================================================|)\n");	
    printf("\t\t\t     (|  There you saw the rabbit. It first looks normal but then suddenly it start shinning  |)\n");
    printf("\t\t\t     (|  it become so bright that you unable to see anything. Then suddenly a strange darkness|)\n");
    printf("\t\t\t     (|  appears. But you spotted a shinning thing on the ground. You blindly try to pick it. |)\n");
    printf("\t\t\t     (|  But the old man hold your hand and give you a unique gloves which bring out from his |)\n");
    printf("\t\t\t     (|  pocket. That thing was look like a watch which was showing multiple times of Time    |)\n");
    printf("\t\t\t     (|***************************************************************************************|)\n");
    printf("\t\t\t     (|  You wear the watch on your hand.                                                     |)\n");
	printf("\t\t\t     (|=======================================================================================|)\n");
	Sleep(10000);
    printf("\t\t\t     (|***************************************************************************************|)\n");
    printf("\t\t\t     (|   Press 'n' if you want to discover more. Otherwise 'y' to continue your journey.     |) \n");
    printf("\t\t\t     (|***************************************************************************************|)\n");
    printf("\t\t\t~>");
    scanf(" %c",&Journey_con);

			system("cls");
      			if(Journey_con=='y' || Journey_con=='Y')
    				{
    					condition=1;
    				}
    				
    		}
    		else if(visited_east==1)
    		{
    			char Journey_continue[100];
    			printf("\t\t\t     (|There is nothing you already visited here  |)\n");
    			printf("\t\t\t     (|    You want to Continue your Journey (y/n)|) \n");
				int back_east_condition=0;
				while(back_east_condition==0)
				{
					printf("\n\t\t\t~>");
    				scanf("%s",Journey_continue);
					if(strlen(Journey_continue)==1)
					{
    			     			if((strcmp(Journey_continue,"y")==0) ||(strcmp(Journey_continue,"Y")==0))
									{
										condition=1;
										back_east_condition=1;
									}
									else if(((strcmp(Journey_continue,"N")==0) || (strcmp(Journey_continue,"n")==0)))
									{
										back_east_condition=1;
										condition=0;
									}
									else
									{
										printf("\n\t\t\t ????????? INVALID INPUT ????????");
									}
					}
					else
					{
						printf("\n\t\t\t (| !!!!!! INVALID INPUT !!!!!!)");
					}
    			}
			}
	 }
 
	 else
	 {
	 	printf("\n\t\t\t**Wrong input**");
	 	}
	}
}
	else if(R_choice_y_n()=='n')
	{
	
        Temple_gate();
		return 1;
	}
		return 0;
}

void R_Story_line_path2_Rabbit()
{
	printf("\t\t\t     (|**************************************************************************************|)\n");
    printf("\t\t\t     (|  After you have passed the village you were almost sliped into a dark and deep hole  |)\n");
    printf("\t\t\t     (|  in the middle of forest. You were about to pass that hole then suddenly a rabbit    |)\n");
    printf("\t\t\t     (|  cut your way and look at you from little far. It was not look like normal rabbit.   |)\n");
    printf("\t\t\t     (|  eyes were dark black with shinning skin. You have choice to follow it or just ignore|)\n");
    printf("\t\t\t     (|  it to. This marks the beginning of your adventure.                                  |)\n");
    printf("\t\t\t     (|**************************************************************************************|)\n");
    printf("\t\t\t     (| Remember! Every step will lead you to another adventure or it may end it right there.|)\n");
    printf("\t\t\t     (|**************************************************************************************|)\n");
    printf("\t\t\t     (|                       You want to follow or not (y/n)                                |)\n");
    printf("\t\t\t     (|**************************************************************************************|)\n");
   
    
    }
    
char R_choice_y_n()
{
	char choice[100],y='y',n='n';
	int rabbit_choise=0;
	system("cls");
	while(rabbit_choise==0)
	{
	R_Story_line_path2_Rabbit();
	printf("\n\t\t\t~>");
	scanf("%s", choice);
	printf("\n");
	if(strlen(choice)==1)
	{
		
		if((strcmp(choice,"y")==0) ||(strcmp(choice,"Y")==0))
		{
			++rabbit_choise;
			return choice[0];
		}
		else if((strcmp(choice,"n")==0) ||(strcmp(choice,"N")==0))
		{
		rabbit_choise=1;
		return choice[0];
	
		}
		else
		{
		printf("\n\t\t\t ???????INVALID INPUT???????\n");
		}
	}
	else
	{
		printf("\n\t\t\t??????? INVALID INPUT ??????");
	}
	Sleep(2000);
	system("cls");
	}
		
}	
    
int R_Bar_story()
{	
	printf("\t\t\t     (|=======================================================================|)\n");
	printf("\t\t\t     (|WHEN YOU REACHED THE DOOR THERE WAS WRITTEN.......                     |)\n");
	printf("\t\t\t     (|\"Beware,");
	Sleep(500);
	printf(" for");
	Sleep(500);
	printf(" the");
	Sleep(500);
	printf(" Door");
	Sleep(500);
	printf(" Holds");
	Sleep(500);
	printf(" Secrets");
	Sleep(500);
	printf(" That");
	Sleep(500);
	printf(" Hunger");
	Sleep(500);
	printf(" FOr");
	Sleep(500);
	printf(" Your");
	Sleep(500);
	printf(" Fear          |)\n"); 
	printf("\t\t\t     (|Do you want to Enter                                           	      |)\n");
	printf("\t\t\t     (|=======================================================================|)\n");
	printf("\t\t\t     (|                         (Y/N)                                         |)\n");
	printf("\t\t\t     (|=======================================================================|)\n");
	char Bar_enter_decision[50];
	int condition_bar=1;

	while(condition_bar==1)
	{
	scanf(" %s", Bar_enter_decision);
	//if you input wrong input 
	if(strlen(Bar_enter_decision)==1)
	{
		//if user chose to enter the bar
	if(Bar_enter_decision[0]=='y' || Bar_enter_decision[0]=='Y')
	{
		condition_bar=0;
		printf("\t\t\t     (|======================================================================================|)\n");
		printf("\t\t\t     (| You enter the bar, its heavily crowded.                                              |)\n");
		printf("\t\t\t     (| You drink a glass of water and a monkey in a cage catches your eye...                |)\n");
		printf("\t\t\t     (| there is a man next to it lets buy it :D                                             |)\n");
		printf("\t\t\t     (| Owner,\"You have to play a game with me if you want it\".                            |)\n");
		printf("\t\t\t     (|======================================================================================|)\n");
		printf("\t\t\t     (|                Do you want to play it or not(y/n)                                    |)\n");
		printf("\t\t\t     (|======================================================================================|)\n");
		char decision_monkey[50];
		printf("\n\t\t\t ~>");
		scanf(" %s",&decision_monkey);
		system("cls");

		if(strlen(decision_monkey)==1)
		{
		//if user choose to help the monkey
		if(decision_monkey[0]=='y' || decision_monkey[0]=='Y')
		{
			
			system("cls");
			if(watch_present_lost!=0)
			{
				printf("\t\t\t     (|======================================================================================|)\n");
				printf("\t\t\t     (|Stranger: Remember! If you lose you have to give me something.............            )|\n");
				printf("\t\t\t     (|======================================================================================|)\n");
			}
				
			else
			{
				printf("\t\t\t     (|======================================================================================|)\n");
				printf("\t\t\t     (|Stranger: Remember! If you lose you have to give me something.............            )|\n");
				printf("\t\t\t     (|======================================================================================|)\n");
			}
	        printf("\t\t\t     (|======================================================================================|)\n");
			printf("\t\t\t     (|Stranger:                                                                             |)\n");
			printf("\t\t\t     (|You have 5 cards here. 3 of them contain poisoned fruit and 2 of                      |)\n");
			printf("\t\t\t     (|them contained non-poison bananas. Whatever came out from the card                    |)\n");
			printf("\t\t\t     (|will be given to Monkey. And if monkey dies you lose and if dont                      |)\n");
			printf("\t\t\t     (|then it is yours.                                                                     |)\n");
			printf("\t\t\t     (|======================================================================================|)\n");                              
						printf("\n\t\t\t _____   _____   _____   _____   _____ ");
                        printf("\n\t\t\t|**   | |**   | |   **| |**   | | **  |");
                        printf("\n\t\t\t|   **| |     | |     | |   **| |   **|");
                        printf("\n\t\t\t| **  | |**   | |**   | |***  | | **  |");
                        printf("\n\t\t\t|_____| |_____| |_____| |_____| |_____|");
						printf("\n\t\t\t   1       2       3       4       5   ");
			char Monkey_choice[10];
			int saver_card;
			srand(time(NULL));
			saver_card=rand()%5 + 1;
			
			int Monkey;
			while(1)
			{
				printf("\n\t\t\t~>");
			    scanf("%s", Monkey_choice);
				if(strlen(Monkey_choice)==1)
				{
					
					int Monkey= Monkey_choice[0] - '0';
			if((Monkey==1) || (Monkey==2) || (Monkey==3) || (Monkey==4) || (Monkey==5))
				{
				break;
				}
			else
			 {
				printf("\n\t\t\t !!!!!Invalid input!!!!!\n");
				Sleep(2000);
				system("cls");
						printf("\n\t\t\t _____   _____   _____   _____   _____ ");
                        printf("\n\t\t\t|**   | |**   | |   **| |**   | | **  |");
                        printf("\n\t\t\t|   **| |     | |     | |   **| |   **|");
                        printf("\n\t\t\t| **  | |**   | |**   | |***  | | **  |");
                        printf("\n\t\t\t|_____| |_____| |_____| |_____| |_____|");
						printf("\n\t\t\t   1       2       3       4       5   ");
			
			  }
			}
			else
			{
				printf("\n\t\t\t(|!!!!!!! INVALID INPUT !!!!!!!)\n");
			}
			}
			printf("\t\t\t     (|======================================================================================|)\n");
			printf("\t\t\t     (|Stranger: Lets see if the Monkey dies or lives!!                                      |)\n");
			printf("\t\t\t     (|======================================================================================|)\n");
			if(Monkey==saver_card)
			{
				printf("\t\t\t     (|====================================================================|)\n");
				printf("\t\t\t     (|Stranger: Why it is not dying????? -o-                              |)\n");
				printf("\t\t\t     (| You open the cage and monkey jumps on your shoulder                |)\n");
				printf("\t\t\t     (|Player: LETS GO BUDDY!      yayyy you saved the monkey!!!           |)\n");
				printf("\t\t\t     (|====================================================================|)\n");
				monkey_presence=1;
				return 1;
				}
			else
			{
				printf("\t\t\t     (|=====================================================================|)\n");
				printf("\t\t\t	   (|Monkey: ka! ka! ka! x_x  ......                                      |)\n");
				printf("\t\t\t     (|Stranger: Looks like some one owes me something!!???                 |)\n");
				printf("\t\t\t     (|                     Don't youuu????                                 |)\n");
				printf("\t\t\t     (|=====================================================================|)\n");
				
				if(watch_present_lost!=0)
				{
					
					printf("\t\t\t     (|=================================================================|)\n");
					printf("\t\t\t     (|Player: Take it! This Watch is yours                             |)\n");
					printf("\t\t\t     (|=================================================================|)\n");
					Sleep(2000);
					watch_present_lost=0;
					int watch=0;
					return watch_present_lost;
					
	              }
				
				else
				{	  printf("\t\t\t     (|================================================================|)\n");
				      printf("\t\t\t	 (|Player: I have nothing to give                                  |)\n");
				      printf("\t\t\t     (|Stranger: Put him in the cage buahahaaha                        |)\n");
					  printf("\t\t\t     (|================================================================|)\n");
					  printf("\n\t\t\t    ****************RETURNING TO CHECKPOINT*************");
					  Sleep(5000);
					  visited_west=0;
					  R_Rabbit_path_directions();
				      return 1;
				     }
				      
				
					
				}
			}
			
	
	else if(decision_monkey[0]=='n' || decision_monkey[0]=='N')
	{
		return 0;
	}
	
	else{
			printf("\n\t\t\t !!!!Invalid INput!!!!!\n");
	}
		}
		else
		{
			printf("\n\t\t\t !!!!  Invalid Input !!!!!\n");
		}
	}
	else if((Bar_enter_decision[0]=='n' || Bar_enter_decision[0]=='N'))
	{
		condition_bar=0;
		return 1;
	}
	else
	{
		printf("\n\t\t\t !!!!! INvalid INput !!!!!\n");
	}
	}
	else
	{
		printf("\n\t\t\t !!!! Invalid INput !!!!!\n");
	}
	}
}



