#ifndef ENDING_SCRIPT_WITHOUT_OLDMAN_H
#define ENDING_SCRIPT_WITHOUT_OLDMAN_H


int Without_oldman(char* text);
int with_out_old_man();

#endif