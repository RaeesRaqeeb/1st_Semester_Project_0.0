#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include<windows.h>
#include"End_script_with_oldman.h"

int with_old_man(char* text) {
    int len = strlen(text);

    for (int i = 0; i < len; i++) {
        printf("%c", text[i]);
      
        Sleep(100);  }

    printf("\n");
}

int old_man() 
{
    printf("\n\t\t\t********************** GAME ENDING ***********************");
    with_old_man("\nYou reach the treasure. There's a bowl placed in the middle of the room, a bright light shining on it. It's filled with water, but no ordinary water. It's taken from the Fountain of Youth. It gives you eternal life.");

    sleep(1);

    with_old_man("As you extend your hand to grab it, someone snatches it from you. Oh waittt, it's the old man...");

    sleep(1);

    with_old_man("He betrayed you...");

    sleep(1);

    with_old_man("He drank the water and turned into a young man.");

    sleep(1);

    with_old_man("Oh well, after all, it's about the journey and not the destination.");

    sleep(1);

    with_old_man("Let's just go back home.");
    Sleep(300);
    return 0;
}
