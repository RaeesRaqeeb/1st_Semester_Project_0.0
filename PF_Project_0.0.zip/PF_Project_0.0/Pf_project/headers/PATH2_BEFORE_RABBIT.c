#include<stdio.h>
#include<time.h>
#include<string.h>
#include<windows.h>
#include<conio.h>
#include"Path1_Rabbit_header.h"
#include"Path2_header.h"
#include"Global_variable.h"

//Main function of path 2
int path2_start(void)
{
	printf("\t\t\t     ---------------------------------CHECKPOINT-------------------------------------------------\n");
	Sleep(2000);
	system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  Safe option to use this way !! this seems easy the road is clean the sky is clear   |)\n");
    printf("\t\t\t     (|  but WAIT its a dead end XXXXXXXXXXX theres a cliff infront of you!!!                |)\n");
	printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|                       O                                                              |)\n");                            
	printf("\t\t\t     (|                      /|\\                                                             |)\n");
	printf("\t\t\t     (|                      / \\                                                             |)\n");                                                                 
    printf("\t\t\t     (|             _________________                    __________________                  |)\n");
    printf("\t\t\t     (|             \\\\   \\                                          ////                     |)\n");
    printf("\t\t\t     (|             \\\\   \\                                          ////                     |)\n");
    printf("\t\t\t     (|             \\\\   \\                                          ////                     |)\n");
    printf("\t\t\t     (|             \\\\   \\           /\\   /\\     /\\              ////                        |)\n");
    printf("\t\t\t     (|             \\\\\\  \\          ||    ||      ||              /////                      |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
	printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(10000);
    system("cls");
    
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  Thereis  a bridge here but to use it you must pass the troll that lives under the     |)\n");
    printf("\t\t\t     (|  bridge. He only let those pass who answer his questions !!!!                        |)\n");
	printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");                            
	printf("\t\t\t     (|                                .--.                                                  |)\n");
	printf("\t\t\t     (|                               |o_o |                                                 |)\n");                                                                 
    printf("\t\t\t     (|                               |    |                                                 |)\n");
    printf("\t\t\t     (|                              //    \\\\                                                |)\n");
    printf("\t\t\t     (|                             (|     |)                                                |)\n");
    printf("\t\t\t     (|                            /'\\   _/`\\                                                |)\n");
    printf("\t\t\t     (|                           \\___)=(___/                                                |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
	printf("\t\t\t     (|                           GOOOD LUCKKK                                               |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(10000);
    system("cls");
    
    
    
	int num4=1,Points_get=0;
	int num=0,num2=2,input1,compare;
	
	while(num4<=2)
	{
	 
	 int User_input;
	
	 
	 compare=0;
	 srand(time(0));
	 compare=Random_generate(num,num2);
	 if(compare==0)
	 {
	 
	printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  ******************************** QUESTIONS :  ************************************  |)\n");
    printf("\t\t\t     (|  What is the probability of getting odd number as the sum of the number of two dice  |)\n");
    printf("\t\t\t     (|  rolled.....                                                                         |)\n");
    printf("\t\t\t     (|  NOTE!!!                                                                             |)\n");
    printf("\t\t\t     (|  Input should be in percentage like 50,70 etc.                                       |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                            ANSWER                                                    |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
	 printf("\n\t\t\tAnswer:");
	 
	 scanf("%d",&User_input);
	 
	 	if(User_input==25)
	 	{
			Points_get=Right_answer(Points_get);
			
		}
	}
	else if(compare==1)
	{
		printf("\t\t\t     (|======================================================================================|)\n");
   	 	printf("\t\t\t     (|  ******************************** QUESTIONS :   ***********************************  |)\n");
    	printf("\t\t\t     (|  I am taken from a mine and shut up in a wooden case, from which I am never released |)\n");
    	printf("\t\t\t     (|  and yet I am used by almost every person..............                              |)\n");
    	printf("\t\t\t     (|  OPTION:                                                                             |)\n");
    	printf("\t\t\t     (|          1) book                                                                     |)\n");
    	printf("\t\t\t     (|          2) pencil                                                                   |)\n");
    	printf("\t\t\t     (|          3) everything                                                               |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                            what am i ????????                                        |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		
		 printf("\n\t\t\tAnswer:");
	scanf("%d",&input1);
		if(input1==2)
		{
			Points_get=Right_answer(Points_get);
		}
	}
	else if(compare==2)
	{
		int value1,value2;
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  ******************************** QUESTIONS :   ***********************************  |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|            For what values of 'x' equation |x-3| = 2 is satisfied  ??                |)\n");
    	printf("\t\t\t     (|  NOTE:                                                                               |)\n");
    	printf("\t\t\t     (|        Give both values                                                              |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                      ANSWER??                                        |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	
		 printf("\n\t\t\tAnswer:");
		scanf("%d",&value1);
		printf("\nValue_2: ");
		scanf("%d",&value2);
		if((value1==1 || value1==5) && value1!=value2 && value2==1 || value2==5)
		{
		
			Points_get=Right_answer(Points_get);
			
		
		}
	}
	else
	{
	printf("\nChecking %d\n",Random_generate(num,num2));
	}
	system("cls");
	++num4;
    }
    if(Points_get==2)
    {
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  congrats**** you passed the troll's questionnair !!!!                               |)\n");
    	printf("\t\t\t     (|       you can pass the bridge now safely :)                                          |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
  	    Sleep(7000);
   
	system("cls");
     }
     else
     {
     	
     	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  oh no you could'nt answer the troll's questions !!!!!!!!!!!!!!!!!!!!!!!!!!          |)\n");
    	printf("\t\t\t     (|  You only got %d answers correct.                                                    |)\n", Points_get);
    	printf("\t\t\t     (|       you can't pass the bridge :(  guess you gotta go back home then !!!!           |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                       BYEEE                                          |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		Sleep(7000);
		system("cls");
		printf("\t\t\t     (|-------------------------returning to checkpoint--------------------------------------|)\n");
		Sleep(3000);
     	path2_start();
		//checkpoint one 
     	//return 0; 
		
	}
	
	// **************************OLD WOMEN STORY ************************************
	Story_telling();
	int checker=0;
	char yes={'y'},no={'n'};
	char input[10];
	
	while(checker<1)
	{
		
	printf("\nYOUR CHOICE:");
	scanf(" %s", input);
	
	if(strlen(input)==1)
{
	if(input[0]==yes)
	{
		//Further process
		++checker;
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  she has seen many people pass by here and no one yet stopped to say hi!! :(         |)\n");
    	printf("\t\t\t     (|  you were the first one :D                                                           |)\n");
    	printf("\t\t\t     (|  she wants to play a game of rock papper scissors with you if you win THREE times    |)\n");
    	printf("\t\t\t     (|  you might win a prize ;)                                                            |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                     READYY !!!!!!                                    |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		Sleep(10000);
		Rock_paper_scissor();		

	}
	else if(input[0]==no)
	{
		//Game will proceed
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  its ok you can ignore the poor old lady -_-                                         |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                            continue your journey                                     |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		
		++checker; 
	}
	else
	{
		printf("\n\t\t\t ?????? Invalid input ?????");
	}
}
else
{
	printf("\n\t\t\t ??????? INVALID INPUT ???????");
}
	
	
	}
	
	Sleep(500);
	system("cls");
	garden_story();
	//*********************OLD WOMEN END*************************
	
}
//****************************************************************************************************

//***********************************GARDAN_STORY*************************************************
int garden_story()
{
	int result;
		printf("-------------------------------CHECKPOINT--------------------------------------------------------------\n");
		Sleep(3000);
		system("cls");
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  Passing through the jungle you come across a beautiful garden!!! with flowers and   |)\n");
    	printf("\t\t\t     (|  fruit everywhere. oh such a pretty flowerr!!                                        |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|                                /-^-\\                                                 |)\n");
    	printf("\t\t\t     (|                               /  |  \\                                                |)\n");
    	printf("\t\t\t     (|                              |   o   |                                               |)\n");
    	printf("\t\t\t     (|                              \\_^_^_/                                                 |)\n");  
    	printf("\t\t\t     (|                                 ||                                                   |)\n");
    	printf("\t\t\t     (|                                 ||                                                   |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		Sleep(10000);
		system("cls");
		
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  OHH WAITTT ITS POISONOUSS and you touched it :O                                     |)\n");
    	printf("\t\t\t     (|  you are dying slowly !!!!                                                           |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|  MAN: i can give you the antidote if you tell me the lie !!!                         |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|   ohh good you just have to tell which one of the facts is false!! thats pretty easy |)\n");
    	printf("\t\t\t     (|   right ?!!                                                                          |)\n");  
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                       good luckkk                                                    |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	Sleep(10000);
	system("cls");
	result=Garden_lie1()+Garden_lie2()+Garden_lie3();
	if(result==4)
	{ 
		printf("\t\t\t     ******************Your answers are correct you win the life for now**************************");
		Sleep(2000);
	}
	else
	{
		printf("\n\t\t\t    ***************************Sorry son Today was not your day, Death is coming for you********************************\n");
		Sleep(3000);
		printf("\n\t\t\t *********RETURNING TO LAST CHECKPOINT*********");
		Sleep(3000);
		system("cls");
		garden_story();
	
	}


	
	Rabbit();
		
}
	


//************************************FUNCTIONS DEFINITION**********************************************

//**********************DICE_GAME**************************

//This functio will give us random values 
int Random_generate(int num1, int num4)
{
	int i,num6;
	for(i=0;i<1;i++)
	{
		
		 num6=(rand()%(num4-num1+1))+num1;
		
	}
	return num6;
}


// THis function is called when user input correct answer
int Right_answer(int correct)
{	
	int num=0;
	printf("\nGreat! your answer is right\n");
	num=++correct;
	return num;
}

//*****************************DICE GAME END ******************************************


/////_______________________--game with old woamn-----------------------

void Rock_paper_scissor()
{
	srand(time(0));
	char  User_move[10];
	int min=0,max=2, machine_input,count_rounds=0,count_wins=0, Checker=0;

	while(count_rounds<3 && count_wins<3)
	{
		system("cls");
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|     CHOOSE ONE                                                                       |)\n");
    	printf("\t\t\t     (|      1) rock                                                                         |)\n");
    	printf("\t\t\t     (|      2) paper                                                                        |)\n");
    	printf("\t\t\t     (|      3) scissor                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                SHOOOTTTT                                             |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");

	printf("\n\t\t\tAnswer:");
	scanf("%s", User_move);
	if(strlen(User_move)==1)
	{
	if(User_move[0]=='1' || User_move[0]=='2' ||User_move[0]=='3')
	{
	machine_input=(rand()%(max-min+1))+min;
	int value= User_move[0] - '0';
	Checker+=Condition(value,machine_input);
	//If game will draw we play one more time
	if(Checker>=10)
	{	
		
		Checker-=10;
		continue;
	}
	else if (Checker==1)
	{
		++count_wins;
		}
	}
	
	//For wrong input
	else
	{
		printf("\t\t\t     \n******************************* WRONG INPUT ********************************************\n");
	}
}
	else
	{
		printf("\n\t\t\t !!!! INVALID INPUT !!!!!\n");
	}
	count_rounds++;
}

if(count_wins==3)
	{
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|   oooo the old lady rewarded you with a magical crossbow                             |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                              such a nice old lady :)                                 |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	Sleep(2000);
	FILE *NEWGAME_FILE;
            NEWGAME_FILE = fopen(user_file, "a");
            if(NEWGAME_FILE==NULL)
            {
                printf("Error in opening file");
            }
             fputs("\nweapon:1", NEWGAME_FILE);
             fclose(NEWGAME_FILE);
		
	}	


	else
	{
		FILE *NEWGAME_FILE;
            NEWGAME_FILE = fopen(user_file, "a");
            if(NEWGAME_FILE==NULL)
            {
                printf("Error in opening file");
            }
             fputs("\nweapon:0", NEWGAME_FILE);
             fclose(NEWGAME_FILE);
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|     oh ooo you got a really bad luck XD sure you wanna continue ??                   |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|              haha good luck with the rest of your journey                            |)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                                                                      |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
		printf("\n\nYou doesn't win all three times, you have wasted your time");
		Sleep(9000);
		system("cls");
	}
	


 }


//Condition checker function of rock paper scissor game
int Condition(int user, int machine)
{
	char R_P_S[3]={'R','P','S'};
	int point;
	point=0;
	
	//Condition for game
	if(R_P_S[machine]=='R' && R_P_S[user-1]=='S')
	{
		printf("You lose, Old Women move was ROCK");
		
	}
	else if(R_P_S[machine]=='R' && R_P_S[user-1]=='P')
	{
		printf("You win, Old Women move was Rock\n");
		++point;
	}
	else if(R_P_S[machine]=='P' && R_P_S[user-1]=='S')
	{
		printf("You win, old women move was Paper\n");
		++point;
	}
	else if(R_P_S[machine]=='P' && R_P_S[user-1]=='R')
	{
		printf("You lose, Old Women move was Paper");
		
	}
	else if(R_P_S[machine]=='S' && R_P_S[user-1]=='R')
	{
		printf("You win, Old woman move was Scissor\n");
		++point;
	}
	else if(R_P_S[machine]=='S' && R_P_S[user-1]=='P')
	{
		printf("You lose, Old Women move was Scissor\n");
		
	}
	//if both played same moves
	else if((R_P_S[machine]=='R' && R_P_S[user-1]=='R')||(R_P_S[machine]=='S' && R_P_S[user-1]=='S')||(R_P_S[machine]=='P' && R_P_S[user-1]=='P'))
	{
		printf("Game Draw, Both moves were same\n");
		point=10;
	}
	Sleep(2000);
	system("cls");
	return point;

}



void Story_telling()
{
	
	    printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|   On your way through the dark forest you encounter an old mysterious lady!!!!       |)\n");
    	printf("\t\t\t     (|   what is she doing here wanna know ????                                             |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                                   ((((y/n))))                                        |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	
	
		
	}
	
//*********************************************OLD WOMEN FUNCTIONS END *************************************************************	
	
	
	
//*********************************************GARDEN_STORY*******************************
int Garden_lie1()
{
	int user_value1;
	
	 	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  1) Lightning never strikes the same place twice                                     |)\n");
    	printf("\t\t\t     (|  2) The Earth orbits the Sun.                                                        |)\n");
    	printf("\t\t\t     (|  3) Objects with some mass attracts each other                                       |)\n");	
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                    choose the liee                                                   |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	
	printf("\n\t\t\tAnswer:");
	scanf("%d",&user_value1);
	system("cls");
	return user_value1;
}

int Garden_lie2()
{
	int user_value2;
	
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  1) Humans only use 10 percent of their brains                                        |)\n");
    	printf("\t\t\t     (|  2) All living things are made up of a livingthing.                                  |)\n");
    	printf("\t\t\t     (|  3) Conservation of energy                                                           |)\n");	
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                    choose the liee                                                   |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");
	
	printf("\n\t\t\tAnswer:");
	scanf("%d",&user_value2);
	system("cls");
	return user_value2;
}

int Garden_lie3()
{
	int user_value2;
	 
		printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|  1) The Earth is annular in shape                                                    |)\n");
    	printf("\t\t\t     (|  2) Bats are blind.                                                                  |)\n");
    	printf("\t\t\t     (|  3) The universe is constantly expanding                                             |)\n");	
    	printf("\t\t\t     (|======================================================================================|)\n");
    	printf("\t\t\t     (|                    choose the liee                                                   |)\n");
    	printf("\t\t\t     (|======================================================================================|)\n");

	printf("\n\t\t\tAnswer:");
	scanf("%d",&user_value2);
	system("cls");
	return user_value2;
}

