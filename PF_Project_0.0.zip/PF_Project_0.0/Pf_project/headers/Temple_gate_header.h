#ifndef TEMPLE_GATE_HEADER_H
#define TEMPLE_GATE_HEADER_H

int Temple_gate();

#endif