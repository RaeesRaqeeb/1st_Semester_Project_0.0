#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include<windows.h>
#include"Temple_gate_header.h"
#include"Global_variable.h"

// Function to clear the screen

int Temple_gate() 
{
    srand(time(NULL));
    int score = 0;
    int correctCount = 0;
    char userChoice[100];
    
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  Finally you are here at the end of your journey, theres a temple in front of you    |)\n");
    printf("\t\t\t     (|  but to enter it you must first unlock the huge gate.                                |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    if(monkey_presence==0)
    {
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                _______________                                                       |)\n");
    printf("\t\t\t     (|               |  __|__|__|__  |                                                      |)\n");
    printf("\t\t\t     (|               | |  |  |  |  | |                                                      |)\n");
    printf("\t\t\t     (|               | |__|__|__|__| |                                                      |)\n");
    printf("\t\t\t     (|               | |  |  |  |  | |                                                      |)\n");
    printf("\t\t\t     (|               | |__|__|__|__| |                                                      |)\n");
    printf("\t\t\t     (|               |_______________|                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(3000);
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  A PICTURE WILL BE DISPLAYED YOU HAVE TO MEMORIZE IT AND CHOOSE THE CORRECT ANSWER   |)\n");
    printf("\t\t\t     (|  YOU WILL BE GIVEN 5 SECONDS !!!!                                                    |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                             GOOD LUCKK                                               |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(3000);
do{
    correctCount=0;
	system("cls");
	printf("\t\t\t     (|===================================================================================|)\n");
    printf("\t\t\t     (|                           /\\_/\\                                                   |)\n");
    printf("\t\t\t     (|                          ( o.o )                                                  |)\n");
    printf("\t\t\t     (|                           > ^ <                                                   |)\n");
    printf("\t\t\t     (|===================================================================================|)\n");

    Sleep(200);
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|    1) cat                                                                            |)\n");
    printf("\t\t\t     (|    2) gun                                                                            |)\n");
    printf("\t\t\t     (|    3) sword                                                                          |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                 CHOOSE                                               |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    int cat_condition=0;
    while(cat_condition==0)
{
        
    printf("\n\t\t\t~>");
    scanf("%s", userChoice);
    if(strlen(userChoice)==1)
    {
        char cat[]="1";
    if (strcmp(userChoice,cat)==0) 
        {
        correctCount++;
        printf("\n\t\t\t ***Correct!***\n");
        cat_condition=1;
        } 
        else if(strcmp(userChoice,"2")==0 || strcmp(userChoice,"3")==0) 
        {
        printf("Wrong answer!. Try again\n");
        Sleep(2000);
        cat_condition=1;
        
            correctCount = 0;  
        }
        else {
            printf("\n\t\t\t ??????? Invalid Input ????????\n");
        }
    }
            else
            {
                printf("\n\t\t\t (|??????INVALID INPUT??????|)");
            }
}  
        Sleep(1000);
    system("cls");
    printf("\t\t\t     (|================================================================================|)\n");
    printf("\t\t\t     (|                          /-_-\\                                                |)\n");
    printf("\t\t\t     (|                         /  |  \\                                                |)\n");
    printf("\t\t\t     (|                        |   o    |                                               |)\n");
    printf("\t\t\t     (|                         \\_^_^_/                                                |)\n");
    printf("\t\t\t     (|                            ||                                                  |)\n");
    printf("\t\t\t     (|                            ||                                                  |)\n");
    printf("\t\t\t     (|                            ||                                                  |)\n");
    printf("\t\t\t     (|================================================================================|)\n");
  
	Sleep(200);
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|    1) Pen                                                                            |)\n");
    printf("\t\t\t     (|    2) Flower                                                                         |)\n");
    printf("\t\t\t     (|    3) Cat                                                                            |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                 CHOOSE                                               |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    int flower_condition=0;
    while(flower_condition==0)
{
	scanf("%s", userChoice);
    if(strlen(userChoice)==1)
    {
    if (strcmp(userChoice,"2")==0 ) 
        {
        correctCount++;
        flower_condition=1;
        printf("Correct!\n");
        }
         else {
        printf("Wrong! Game Over.\n");
            correctCount = 0;  
        }
    }
    else{
        printf("\n\t\t\t (|INVALID INPUT)");
    }
}
        system("cls");
        
    printf("\t\t\t     (|================================================================================|)\n");
    printf("\t\t\t     (|                        /\\                                                       |)\n");
    printf("\t\t\t     (|                       /  \\                                                      |)\n");
    printf("\t\t\t     (|                        ||                                                      |)\n");
    printf("\t\t\t     (|                        ||                                                      |)\n");
    printf("\t\t\t     (|                        ||                                                      |)\n");
    printf("\t\t\t     (|================================================================================|)\n");
    Sleep(200);    
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|    1) cat                                                                            |)\n");
    printf("\t\t\t     (|    2) Flower                                                                         |)\n");
    printf("\t\t\t     (|    3) arrow                                                                          |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                 CHOOSE                                               |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    int Arrow_condition=0;
    while(Arrow_condition==0)
    {

    scanf("%s", userChoice);
    if(strlen(userChoice)==1)
    {
    if (strcmp(userChoice,"3")==0) 
        {
            correctCount++;
            Arrow_condition=1;
            printf("\n\t\t\t************Correct!*********\n");
        }
     else 
        {
            printf("\n\t\t\t ??????? INVALID INPUT ???????\n");
            correctCount = 0; 
        }
    }
    else
    {
        printf("\n\t\t\t ???????? INVALID INPUT ???????");
    }
    }
  if (correctCount == 3)
         {         
           
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|  Oh the door opened now we can go inside!!!                                         |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|                                                                                      |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
         }
      else
    {
	
	 printf("\n\t\t\t Game Over. Your final score is %d.\n try again!!", score);

    } 
  
    }while(correctCount!=3);
    }
else if(monkey_presence==1)
{
    Sleep(2000);
    printf("\n\t\t\t\t(| Wait what is monkey doing. He is trying to help you.)|\n");
    correctCount=3;
    printf("\n\t\t\t\t(| MOnkey is trying to break the lock system.)|\n");
    Sleep(2000);
      if (correctCount == 3)
         {         
           
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (| (Thank you monkey!) the door opened now we can go inside!!!                          |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|                                                                                      |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
         }
      else
    {
	
	 printf("\n\t\t\t Game Over. Your final score is %d.\n try again!!", score);

    } 
    if(correctCount!=3)
    {
        printf("\n\t\t\t\t(| Your answers are wrong! Try again|)\n");
    }
}
    

      

    
        return 0;
}




