#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include "Path1_Rabbit_header.h"
#include "PATH_1_Old_Men_and_child.h"
#include"Path2_header.h"
#include"Global_variable.h"

//It is the main function of this file
int PATH_1_Old_Men_and_child()
{
    int without_oldman=0;
    without_oldman=old_man_monologue();
    if(without_oldman!=0)
    {
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  congragulation you got yourself a companion for the rest of the journey!!! hope he  |)\n");
    printf("\t\t\t     (|  he finds you helpful or god knows what he will do to you XD anyways lets move to    |)\n");
    }
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  the next destination................................................................|)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(3000);
    village_monologue();
    cave_monologue();
    Rabbit();
}

//This function is used to convert the char input from the user to lowercase 
char tol(char ch)
{ 
    if (ch >= 65 && ch <= 90)
    {
        return   'a' + (ch - 'A' );
    }
        return ch;
}



void old_man_trivia()
{
    char ans_dis[20];
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  *********************************OUESTION 1***************************************  |)\n");
    printf("\t\t\t     (|  !!!!!!!!!!!!!!!!!!im tall when im young and short when im old!!!!!!!!!!!!!!!!!!!!!  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  ????????????????????????????     WHAT AM I      ??????????????????????????????????  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    char q_1[7] = "candle";
    char a_1[7];
    int condition_1 = 0;
    do
    {
        if (condition_1 > 0)
        {
            printf("\t\t\t     *********************************wrongg try again***************************************\n");
        }

        scanf(" %s", a_1);
        for (int j = 0; j<=strlen(a_1); j++)
        {
            a_1[j]=tol(a_1[j]);
        }
        // ans_dis[j] = '\0';

        condition_1++;

        if (condition_1 == 2)
        {
            printf("\t\t\t     ???????????????????????????? need some help? (y/n) ???????????????????????????????????????\n");
            char ans;
            scanf(" %c", &ans);
            if (ans == 'y')
            {
                printf("\t\t\t      I stand tall, giving light to the night when I'm young, but as I age, I shrink\n\t\t\t     and fade away. What am I?\n");
            }
            else if (ans == 'n')
            {
                printf("As you wish");
            }
            else
            {
                printf("\t\t\t     its just like they say \"In the game of life, there are no rehearsals.\" you lost your chance for a hint :(");
            }
        }

        // printf("\n-%s-\n", ans_dis[i]);


    } while (strcmp(q_1, a_1) != 0);

    printf("\t\t\t     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CORRECTT &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
    Sleep(2000);

    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  *********************************OUESTION 2***************************************  |)\n");
    printf("\t\t\t     (|  !!!!!!!!!!!!!!!!!!!!	I have keys but can't open locks? !!!!!!!!!!!!!!!!!!!!!!!!!!!  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  ????????????????????????????     WHAT AM I      ??????????????????????????????????  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    char q_2[9] = "keyboard";
    char a_2[9];
    int condition_2 = 0;

    do
    {
        if (condition_2 > 0)
        {
            printf("\t\t\t     *********************************wrongg try again*****************************************\n");
        }

        scanf(" %s",a_2);
         for (int index = 0; index<=strlen(a_2); index++)
        {
            a_2[index]=tol(a_2[index]);
        }
        // ans_dis[j] = '\0';
        condition_2++;

        if (condition_2 == 2)
        {
            printf("\t\t\t     ???????????????????????????? need some help? (y/n) ???????????????????????????????????????\n");
            char ans;
            scanf(" %c", &ans);
            if (ans == 'y')
            {
                printf("\t\t\t      you are using it right now!!! ;)\n");
            }
            else if (ans == 'n')
            {
                printf("As you wish");
            }
            else
            {
                printf("\t\t\t     its just like they say \"In the game of life, there are no rehearsals.\" you lost your chance for a hint :(");
            }
        }



    } while (strcmp(q_2, a_2) != 0);

    printf("\t\t\t     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CORRECTT &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
    Sleep(2000);

    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  *********************************OUESTION 3***************************************  |)\n");
    printf("\t\t\t     (|  !!!!!!!!!!!!!!!!!!!!	The more you take, the more you leave behind !!!!!!!!!!!!!!! |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  ????????????????????????????     WHAT AM I      ??????????????????????????????????  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    char q_3[10] = "footsteps";
    char a_3[10];
    int condition_3 = 0;

    do
    {
        if (condition_3 > 0)
        {
            printf("\t\t\t     *********************************wrongg try again*****************************************\n");
        }

        scanf("%s", a_3);
        for (int index = 0; index<=strlen(a_3); index++)
        {
            a_3[index]=tol(a_3[index]);
        }
        // ans_dis[j] = '\0';
        condition_3++;

        if (condition_3 == 2)
        {
            printf("\t\t\t     ???????????????????????????? need some help? (y/n) ???????????????????????????????????????\n");
            char ans;
            scanf(" %c", &ans);
            if (ans == 'y')
            {
                printf("\t\t\t      As you move forward, you leave an imprint behind.;)\n");
            }
            else if (ans == 'n')
            {
                printf("As you wish");
            }
            else
            {
                printf("\t\t\t     its just like they say \"In the game of life, there are no rehearsals.\" you lost your chance for a hint :(");
            }
        }


    } while (strcmp(q_3, a_3) != 0);

    printf("\t\t\t     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CORRECTT &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
}

// talks between old man and player
int old_man_monologue()
{
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  you chose to travel on the path less traveled on, quite daring of you!! as you pass |)\n");
    printf("\t\t\t     (|  through the mighty jungle full of bugs, beasts, vampires and demons. you move slowly|)\n");
    printf("\t\t\t     (|  towards your destination....... the sky is barely visible and no sound can be heard.|)\n");
    printf("\t\t\t     (|  but wait whats that???? its hairy and small yet furocious!!!! wait its coming to    |)\n");
    printf("\t\t\t     (|  eat you RUNNNN!!!! oh wait wait its just a old hairy man!!! still dangerous (cant   |)\n");
    printf("\t\t\t     (|  trust anyone you know) want to listen to what he has to say??                       |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|    curious enough???                  (((y/n)))                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    char old_talk[100];
    int Old_man_condition=0;
    while (Old_man_condition==0)
    {
        printf("\n\t\t\t~>");
        scanf(" %s", old_talk);
        if(strlen(old_talk)==1)
        {
        if ((strcmp(old_talk,"n") == 0) || (strcmp(old_talk,"N") == 0))
        {
            
            system("cls");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|  OHHH NOOO :( the old man is sad he refused to let you pass!! its better to be kind  |)\n");
            printf("\t\t\t     (|  sometimes... you chose a bad day to be rude tsk tsk now you wont know what mysteries|)\n");
            printf("\t\t\t     (|  lied on this road oh well anyways you have to move towards the other road see you on|)\n");
            printf("\t\t\t     (|  the other sideee.......                                                             |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            
            return 0;

        }
        else if ((strcmp(old_talk,"y") == 0) || (strcmp(old_talk,"Y") == 0))
        {
            system("cls");
            presence_of_old_man=1;

            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|  after hearing the old mans story it seems he can help you reach it!! :D  BUTTT      |)\n");
            printf("\t\t\t     (|  he must test you first... not a hard test but a simple one you just have to answer  |)\n");
            printf("\t\t\t     (|  some ridlles because this journey can only be completed with BRAINSS!!!!            |)\n");
            printf("\t\t\t     (|  ok some rules:--                                                                    |)\n");
            printf("\t\t\t     (|  --> one word answer                                                                 |)\n");
            printf("\t\t\t     (|  --> all small letters                                                               |)\n");
            printf("\t\t\t     (|  --> hints available ;)                                                              |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|                                       READY ????                                     |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            Sleep(3000);
            old_man_trivia();
            return 0;
        }
        else
        {
            printf("\n\t\t\t??????? INVALID INPUT ??????");
        }
        }
        else
        {
            printf("\n\t\t\t??????? INVALID INPUT ??????");
        }
    }

    // game played with child
}


//Game played with child 
int child_game()
{
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  poem number 1:                                                                      |)\n");
    printf("\t\t\t     (|                        \" twinkle twinkle little _________\"                          |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                         complete the verse!!!!!!!!!                                  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     option 1: star \n\t\t\t     option 2: stars\n");
    int grade = 0;
    int answer;
    scanf(" %d", &answer);
    if (answer == 1)
    {
        grade++;
    }
    else
    {
        printf("\t\t\t     ************************************* WRONG *******************************************");
    }

    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  poem number 2;                                                                      |)\n");
    printf("\t\t\t     (|                       \"row row row your boat gently down the ______\"                |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                         complete the verse!!!!!!!!!                                  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     option 1: river \n\t\t\t     option 2: stream\n");
    int answer2;
    scanf(" %d", &answer2);
    if (answer2 == 2)
    {
        grade++;
    }
    else
    {
        printf("\t\t\t     ************************************* WRONG *******************************************");
    }

    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  poem number 3;                                                                      |)\n");
    printf("\t\t\t     (|                     \"if you are happy and you know it ____your hands\"               |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                         complete the verse!!!!!!!!!                                  |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     option 1: clap \n\t\t\t     option 2: stomp\n");
    int answer3;
    scanf(" %d", &answer3);
    if (answer3 == 1)
    {
        grade++;
    }
    else
    {
        printf("\t\t\t     ************************************* WRONG *******************************************");
    }
    if (grade >= 2)
    {
        weapon_presence=1;
        system("cls");
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|  CHILD: thanks for helping me with my homework i have a little surprise for you....  |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                * /\\                                                   |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                 /  \\                                                  |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                 | || *                                               |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                *| ||                                                 |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                 | ||                                                 |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                 | ||                                                 |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                 | ||                                                 |)\n");
        Sleep(200);
        printf("\t\t\t     (|                               [------]                                               |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                  ()                                                  |)\n");
        Sleep(200);
        printf("\t\t\t     (|                                  ()                                                  |)\n");
        Sleep(200);
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|   its a magical sword it will help you on your journey ahead!!!!                     |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
        Sleep(300);
      
        return 0;
    }
    else
    { 
           weapon_presence=0;
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|  you got %d out of 3 right!! thanks you did good but not good enough :(              |)\n", grade);
        printf("\t\t\t     (|                                                                                      |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
        printf("\t\t\t     (|                                      BYEE!!!!!!!!                                    |)\n");
        printf("\t\t\t     (|======================================================================================|)\n");
        Sleep(300);
    }
}

// village entry and dialouges
void village_monologue()
{
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  As you continue on the journey to find this ancient treasure    |)\n");
    printf("\t\t\t     (|  you pass through the jungle and encounter a hidden village.                         |)\n");
    printf("\t\t\t     (|  Passing through it you see many new and unique things there are shops and houses,   |)\n");
    printf("\t\t\t     (|  but noone knew this.                                                                |)\n");
    printf("\t\t\t     (|  You meet a child in the village, he needs your help with something and dont't       |)\n");
    printf("\t\t\t     (|  worry, it's not for free ;) !!!!!                                                   |)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                                                                      |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    Sleep(5000);
    system("cls");

    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  CHILD: Will you help me learn these new poems from the outside world ???            |)\n");
    printf("\t\t\t     (|  Its ok if u dont want to :( but remember you only get ONE chance dont mess it up!!! |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|                                    ((((y/n))))                                       |)\n");
    printf("\t\t\t     (|======================================================================================|)\n");
    char ans[100];
    int condition_child_answer=0;
    while(condition_child_answer==0)
{
    printf("\n\t\t\t~>");
    scanf(" %s", ans);
    if(strlen(ans)==1)
    {
        if ((strcmp(ans,"y") == 0) ||(strcmp(ans,"Y") == 0))
            {
            
            child_game();
            condition_child_answer=1;
            }
        else if((strcmp(ans,"n") == 0) ||(strcmp(ans,"N") == 0))
        {
            system("cls");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|  CHILD: its ok i knew you were dumb can't help me with my homework -_-               |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|                                         boohooo                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            FILE *NEWGAME_FILE;
            NEWGAME_FILE = fopen(user_file, "a");
            if(NEWGAME_FILE==NULL)
            {
                printf("Error in opening file");
            }
            char child_weapon[]={"\nweapon:"};
             fputs(strcat(child_weapon,"0"), NEWGAME_FILE);
             fclose(NEWGAME_FILE);
            condition_child_answer=1;
        }
        else
        {
            printf("\n\t\t\t??????? INVALID INPUT ?????????\n");
        }
    }
    else
    {
       // printf("\n\t\t\t ??????? INVALID INPUT ?????");
    }
  }
}

void cave_monologue()
{
    Sleep(6000);
    system("cls");
    printf("\t\t\t     (|======================================================================================|)\n");
    printf("\t\t\t     (|  After passing the village you move towards an old cave which has carts passing in   |)\n");

            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|  you can use the carts to pass now !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!   |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|                               ____________________________                           |)\n");
            printf("\t\t\t     (|                          \\\\   \\                          /                           |)\n");
            printf("\t\t\t     (|                           \\\\   \\                        /                            |)\n");
            printf("\t\t\t     (|                            \\\\   \\                      /                             |)\n");
            printf("\t\t\t     (|                             \\\\   \\                    /                              |)\n");
            printf("\t\t\t     (|                              \\\\\\  \\                  /                               |)\n");
            printf("\t\t\t     (|                                     -----------------                               |)\n");
            printf("\t\t\t     (|                                         (*)    (*)                                   |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|                                                                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
            printf("\t\t\t     (|                                       GOOD LUCK                                      |)\n");
            printf("\t\t\t     (|======================================================================================|)\n");
           Sleep(10000);
            Sleep(5000);
    system("cls");
 
}


