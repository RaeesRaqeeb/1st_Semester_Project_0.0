#ifndef TEMPLE_BEAST_HEADER_H
#define TEMPLE_BEAST_HEADER_H

void Entering_temple();
void Back_form_rabbit();
int fighting_beast();
#endif
