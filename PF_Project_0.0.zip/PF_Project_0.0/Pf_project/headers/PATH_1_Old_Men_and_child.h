#ifndef PATH_1_HEADER_H
#define PATH_1_HEADER_H

int PATH_1_Old_Men_and_child();
int old_man_monologue();
void old_man_trivia();
void village_monologue();
int child_game();
void cave_monologue();

char tol(char ch);

#endif