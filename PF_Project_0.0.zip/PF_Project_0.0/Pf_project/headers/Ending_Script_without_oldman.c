#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include"Ending_Script_without_oldman.h"
#include<windows.h>

int Without_oldman(char* text) 
{
    int len = strlen(text);
    

    for (int i = 0; i < len; i++) {
        printf("%c", text[i]);
        fflush(stdout);
        Sleep(100);  
    }

    printf("\n");
}

int with_out_old_man() 
{
    printf("\n\t\t\t********************** GAME ENDING ***********************");
    Without_oldman("\nYou reach the treasure. There's a bowl placed in the middle of the room, a bright light shining on it. It's filled with water, but no ordinary water. It's taken from the Fountain of Youth. It gives you eternal life.");

    sleep(1);

    Without_oldman("Lucky!!! You get to drink it.");

    sleep(1);

    Without_oldman("Now enjoy your eternal life.");

    sleep(1);

    Without_oldman("But remember...");

    sleep(1);

    Without_oldman("\"Eternal life: a relentless descent into timeless shadows.\"");

    sleep(1);

    Without_oldman("Thank you for playing. Hope you enjoyed it.");

    Sleep(5000);
    return 0;
  
}