#ifndef PATH2_HEADER_H
#define PATH2_HEADER_H

int path2_start(void);
int garden_story();
// int seconds=600;
//***********************************DICE GAME FUNCTION PROTOTYPES*****************************
// int Points_get=0;
int Random_generate(int num1, int num4);
int Right_answer(int correct);

//*********************************OLD WOMEN FUNCTIONS PROTOTYPES******************************
void Story_telling();
void Rock_paper_scissor();
int Condition(int user, int machine);


//**********************************GARDEN_STORY***********************************************
int Garden_lie1();
int Garden_lie2();
int Garden_lie3();

//*********************************TIMER CODE***************************************************
void *timerFunction(void *arg);

#endif